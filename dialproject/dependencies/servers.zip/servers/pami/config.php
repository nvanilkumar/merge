<?php
$apiuri = "http://localhost:8080/scopdial/web/app.php";
$astrihost = "192.168.36.134";
$astriuser = "admin";
$astripass = "123456";