<?php
$apiuri = "http://41.87.218.57/scopdial/web/app.php";
$astrihost = "41.87.218.57";
$astriuser = "admin";
$astripass = "tms88in##";